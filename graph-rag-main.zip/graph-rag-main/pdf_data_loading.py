"""
Script para cargar entidades y relaciones extraídas del PDF en Neo4j.

PREREQUISITOS:
1. Neo4j debe estar corriendo (usar: docker compose up neo4j)
2. Los archivos deben estar en pdf_extraction_output/:
   - entities.csv
   - relations.csv
3. Variables de entorno configuradas en .env o exportadas:
   - NEO4J_HOST
   - NEO4J_PORT
   - NEO4J_USER
   - NEO4J_PASSWORD
"""

import csv
import json
import os
import sys
from uuid import uuid4
from slugify import slugify

from neo4j import GraphDatabase
from dotenv import load_dotenv

load_dotenv()


def escape(string):
    """Escapa strings para uso seguro en Cypher"""
    return json.dumps(string)[1:-1]


def generate_uri(name):
    """Genera un URI único basado en el nombre de la entidad"""
    return slugify(name, separator="_")


def create_indices(driver):
    """Crea índices para mejorar el rendimiento de las consultas"""
    with driver.session() as session:
        # Índices para entidades
        session.run("CREATE INDEX IF NOT EXISTS FOR (e:ENTITY) ON (e.name)")
        session.run("CREATE INDEX IF NOT EXISTS FOR (e:ENTITY) ON (e.uri)")
        # Índices para otros tipos de nodos
        session.run("CREATE INDEX IF NOT EXISTS FOR (e:PERSON) ON (e.name)")
        session.run("CREATE INDEX IF NOT EXISTS FOR (e:ORG) ON (e.name)")
        session.run("CREATE INDEX IF NOT EXISTS FOR (e:GPE) ON (e.name)")
        session.run("CREATE INDEX IF NOT EXISTS FOR (e:LOC) ON (e.name)")
        print("✓ Índices creados")


def insert_entities(driver, entities_file):
    """Inserta entidades desde el CSV extraído del PDF"""
    if not os.path.exists(entities_file):
        print(f"⚠ Archivo no encontrado: {entities_file}")
        return 0

    entities_inserted = 0
    
    # Mapeo de tipos de entidades de spaCy a labels de Neo4j
    entity_type_mapping = {
        'PERSON': 'PERSON',
        'ORG': 'ORG',
        'GPE': 'GPE',  # Geopolitical entity (países, ciudades)
        'LOC': 'LOC',  # Location
        'FAC': 'FAC',  # Facility
        'PRODUCT': 'PRODUCT',
        'EVENT': 'EVENT',
        'WORK_OF_ART': 'WORK_OF_ART',
        'LAW': 'LAW',
        'LANGUAGE': 'LANGUAGE',
        'DATE': 'DATE',
        'TIME': 'TIME',
        'PERCENT': 'PERCENT',
        'MONEY': 'MONEY',
        'QUANTITY': 'QUANTITY',
        'ORDINAL': 'ORDINAL',
        'CARDINAL': 'CARDINAL'
    }

    create_entity_template = """
    MERGE (e:ENTITY {uri: $uri})
    ON CREATE SET 
        e.name = $name,
        e.source = 'pdf',
        e.created_at = timestamp()
    ON MATCH SET
        e.updated_at = timestamp()
    SET e:ENTITY
    RETURN e
    """.strip()

    create_typed_entity_template = """
    MERGE (e:ENTITY {uri: $uri})
    ON CREATE SET 
        e.name = $name,
        e.source = 'pdf',
        e.created_at = timestamp()
    ON MATCH SET
        e.updated_at = timestamp()
    SET e:ENTITY:{label}
    RETURN e
    """.strip()

    with driver.session() as session:
        entities_processed = set()  # Para evitar duplicados
        
        with open(entities_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                entity_name = row.get('text', '').strip()
                entity_label = row.get('label', '').strip()
                
                if not entity_name or len(entity_name) < 2:
                    continue
                
                # Generar URI único
                # El archivo entities.csv ya viene con el nombre correcto (normalizado o no según USE_NORMALIZED_DATA)
                uri = generate_uri(entity_name)
                
                # Evitar duplicados
                entity_key = (uri, entity_label)
                if entity_key in entities_processed:
                    continue
                entities_processed.add(entity_key)
                
                # Escapar el nombre
                name = escape(entity_name)
                
                # Determinar el label de Neo4j
                neo4j_label = entity_type_mapping.get(entity_label, 'ENTITY')
                
                # Crear nodo con label específico si aplica
                if neo4j_label != 'ENTITY' and neo4j_label in ['PERSON', 'ORG', 'GPE', 'LOC', 'FAC']:
                    session.run(create_typed_entity_template, 
                              uri=uri, name=name, label=neo4j_label)
                else:
                    session.run(create_entity_template, uri=uri, name=name)
                
                entities_inserted += 1
                
                if entities_inserted % 100 == 0:
                    print(f"  Procesadas {entities_inserted} entidades...")

    print(f"✓ {entities_inserted} entidades insertadas")
    return entities_inserted


def insert_relations(driver, relations_file):
    """Inserta relaciones desde el CSV extraído del PDF"""
    if not os.path.exists(relations_file):
        print(f"⚠ Archivo no encontrado: {relations_file}")
        return 0

    relations_inserted = 0
    
    # Template para crear relaciones
    create_relation_template = """
    MATCH (from:ENTITY {uri: $from_uri})
    MATCH (to:ENTITY {uri: $to_uri})
    MERGE (from)-[r:RELATED_TO {relation_type: $relation_type}]->(to)
    ON CREATE SET
        r.source = 'pdf',
        r.created_at = timestamp()
    ON MATCH SET
        r.updated_at = timestamp()
    RETURN r
    """.strip()

    # Template para relaciones con tipos específicos
    create_typed_relation_template = """
    MATCH (from:ENTITY {uri: $from_uri})
    MATCH (to:ENTITY {uri: $to_uri})
    MERGE (from)-[r:{relation_name}]->(to)
    ON CREATE SET
        r.source = 'pdf',
        r.relation_type = $relation_type,
        r.created_at = timestamp()
    ON MATCH SET
        r.updated_at = timestamp()
    RETURN r
    """.strip()

    # Mapeo de relaciones comunes a tipos específicos
    relation_type_mapping = {
        'is': 'IS',
        'from': 'FROM',
        'in': 'IN',
        'of': 'OF',
        'to': 'TO',
        'with': 'WITH',
        'at': 'AT',
        'for': 'FOR',
        'on': 'ON',
        'by': 'BY'
    }

    with driver.session() as session:
        relations_processed = set()  # Para evitar duplicados
        
        with open(relations_file, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                subject = row.get('subject', '').strip()
                relation = row.get('relation', '').strip().lower()
                obj = row.get('object', '').strip()
                
                if not subject or not obj or len(subject) < 2 or len(obj) < 2:
                    continue
                
                # Generar URIs
                from_uri = generate_uri(subject)
                to_uri = generate_uri(obj)
                
                # Evitar duplicados
                relation_key = (from_uri, relation, to_uri)
                if relation_key in relations_processed:
                    continue
                relations_processed.add(relation_key)
                
                # Normalizar el tipo de relación
                relation_type = relation_type_mapping.get(relation, relation.upper())
                
                # Determinar si usar relación genérica o específica
                if relation in relation_type_mapping:
                    relation_name = relation_type_mapping[relation].upper()
                    try:
                        session.run(create_typed_relation_template.format(relation_name=relation_name),
                                  from_uri=from_uri, to_uri=to_uri, relation_type=relation_type)
                    except Exception as e:
                        # Si falla, usar relación genérica
                        session.run(create_relation_template,
                                  from_uri=from_uri, to_uri=to_uri, relation_type=relation_type)
                else:
                    session.run(create_relation_template,
                              from_uri=from_uri, to_uri=to_uri, relation_type=relation_type)
                
                relations_inserted += 1
                
                if relations_inserted % 100 == 0:
                    print(f"  Procesadas {relations_inserted} relaciones...")

    print(f"✓ {relations_inserted} relaciones insertadas")
    return relations_inserted


def check_connection(driver):
    """Verifica la conexión a Neo4j"""
    try:
        with driver.session() as session:
            result = session.run("RETURN 1 as test")
            result.single()
            print("✓ Conexión a Neo4j establecida")
            return True
    except Exception as e:
        print(f"✗ Error conectando a Neo4j: {e}")
        return False


def check_existing_data(driver):
    """Verifica si ya hay datos en la base de datos"""
    with driver.session() as session:
        result = session.run("MATCH (n:ENTITY) WHERE n.source = 'pdf' RETURN count(n) as count")
        count = result.single()['count']
        return count


def main():
    """Función principal"""
    print("=" * 60)
    print("CARGA DE DATOS DEL PDF EN NEO4J")
    print("=" * 60)
    
    # Obtener configuración de Neo4j
    host = os.environ.get("NEO4J_HOST", "localhost")
    user = os.environ.get("NEO4J_USER", "neo4j")
    password = os.environ.get("NEO4J_PASSWORD", "EchoesOfWisdom")
    port = os.environ.get("NEO4J_PORT", "7687")
    
    print(f"\nConectando a Neo4j en {host}:{port}...")
    
    # Conectar a Neo4j
    try:
        driver = GraphDatabase.driver(f"bolt://{host}:{port}", auth=(user, password))
    except Exception as e:
        print(f"✗ Error al crear el driver de Neo4j: {e}")
        print("\nAsegúrate de que:")
        print("1. Neo4j está corriendo (docker compose up neo4j)")
        print("2. Las credenciales en .env son correctas")
        sys.exit(1)
    
    # Verificar conexión
    if not check_connection(driver):
        sys.exit(1)
    
    # Verificar datos existentes
    existing_count = check_existing_data(driver)
    if existing_count > 0:
        response = input(f"\n⚠ Ya existen {existing_count} entidades del PDF. ¿Deseas continuar? (s/n): ")
        if response.lower() != 's':
            print("Operación cancelada")
            driver.close()
            sys.exit(0)
    
    # Rutas a los archivos (siempre buscar entities.csv y relations.csv)
    output_dir = "pdf_extraction_output"
    entities_file = os.path.join(output_dir, "entities.csv")
    relations_file = os.path.join(output_dir, "relations.csv")
    
    # Verificar que los archivos existen
    if not os.path.exists(entities_file):
        print(f"\n✗ Error: No se encontró {entities_file}")
        print("Ejecuta primero el notebook pdf_extraction.ipynb para generar los archivos")
        driver.close()
        sys.exit(1)
    
    print(f"📝 Archivos encontrados:")
    print(f"   - Entidades: {entities_file}")
    
    if not os.path.exists(relations_file):
        print(f"⚠ Advertencia: No se encontró {relations_file}")
        relations_file = None
    else:
        print(f"   - Relaciones: {relations_file}")
    
    print(f"\n💡 Los archivos pueden contener datos normalizados o no,")
    print(f"   según la configuración USE_NORMALIZED_DATA en el notebook.")
    
    print("\n" + "=" * 60)
    print("1. CREANDO ÍNDICES")
    print("=" * 60)
    create_indices(driver)
    
    print("\n" + "=" * 60)
    print("2. INSERTANDO ENTIDADES")
    print("=" * 60)
    entities_count = insert_entities(driver, entities_file)
    
    print("\n" + "=" * 60)
    print("3. INSERTANDO RELACIONES")
    print("=" * 60)
    if relations_file and os.path.exists(relations_file):
        relations_count = insert_relations(driver, relations_file)
    else:
        print("⚠ No hay archivo de relaciones para cargar")
        relations_count = 0
    
    # Resumen final
    print("\n" + "=" * 60)
    print("RESUMEN")
    print("=" * 60)
    print(f"Entidades insertadas: {entities_count}")
    print(f"Relaciones insertadas: {relations_count}")
    
    # Verificar resultados
    with driver.session() as session:
        total_entities = session.run("MATCH (n:ENTITY) WHERE n.source = 'pdf' RETURN count(n) as count").single()['count']
        total_relations = session.run("MATCH ()-[r:RELATED_TO]->() WHERE r.source = 'pdf' RETURN count(r) as count").single()['count']
        print(f"\nTotal en la base de datos:")
        print(f"  - Entidades del PDF: {total_entities}")
        print(f"  - Relaciones del PDF: {total_relations}")
    
    driver.close()
    print("\n✓ Proceso completado exitosamente")


if __name__ == "__main__":
    main()

