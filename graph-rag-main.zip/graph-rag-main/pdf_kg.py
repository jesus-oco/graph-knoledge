"""
Clase para interactuar con el grafo de conocimiento del PDF usando RAG.
Orientado al documento: "AWS Documento técnico – Descripción general de Amazon Web Services".
El objetivo es facilitar consultas sobre servicios, categorías, regiones,
características e integraciones descritas en dicho documento.
"""

import os
from typing import List, Any

from openai import OpenAI
from neo4j import GraphDatabase


def format_results_as_markdown_table(results: List[List[Any]]) -> str:
    print(f"PASO 4: Formateando resultados a Tabla Markdown")
    """Formatea los resultados de Neo4j como una tabla Markdown."""
    if not results:
        return ""

    headers = results[0]
    rows_data = results[1:] if len(results) > 1 else []

    columns = len(headers)
    column_widths = [len(str(h)) for h in headers]
    for row in rows_data:
        for i, value in enumerate(row):
            column_widths[i] = max(column_widths[i], len(str(value)))

    def format_row(row, space_char: str = " ") -> str:
        cells = [f"{space_char}{str(value):<{column_widths[i]}}{space_char}" for i, value in enumerate(row)]
        return "|" + "|".join(cells) + "|"

    lines = [
        format_row(headers),
        format_row(["-" * column_widths[i] for i in range(columns)], "-"),
    ]
    for row in rows_data:
        lines.append(format_row(row))
    lines.append("")
    return "\n".join(lines)


class PDFKnowledgeGraph:
    """Clase para interactuar con el grafo de conocimiento del PDF usando RAG."""

    def __init__(self):
        """Inicializa la conexión a Neo4j y el cliente de OpenAI."""
        scheme = os.environ.get("NEO4J_SCHEME", "neo4j")  # neo4j:// recomendado en clusters; bolt:// en single
        host = os.environ["NEO4J_HOST"]
        port = os.environ["NEO4J_PORT"]
        user = os.environ["NEO4J_USER"]
        password = os.environ["NEO4J_PASSWORD"]

        self.driver = GraphDatabase.driver(
            f"{scheme}://{host}:{port}",
            auth=(user, password),
        )

        # OpenAI (SDK v1.x)
        # Asegúrate de tener OPENAI_API_KEY y OPENAI_MODEL en el entorno.
        import httpx
        import ssl
        
        # Configurar cliente HTTP con manejo de SSL
        # Si hay problemas con certificados SSL (proxy corporativo, etc.)
        # puedes configurar OPENAI_SSL_VERIFY=false en el .env
        ssl_verify = os.environ.get("OPENAI_SSL_VERIFY", "true").lower() == "true"
        
        http_client = httpx.Client(
            verify=ssl_verify if ssl_verify else False,
            timeout=60.0
        )
        
        self.openai_client = OpenAI(
            api_key=os.environ.get("OPENAI_API_KEY"),
            http_client=http_client
        )
        self.openai_model = os.environ["OPENAI_MODEL"]

    # ----------------------------- Neo4j helpers -----------------------------

    def query_database(self, query: str) -> List[List[Any]]:
        """Ejecuta una query Cypher en Neo4j y retorna los resultados como [headers, *rows]."""
        with self.driver.session() as session:
            result = session.run(query)
            rows = [r.values() for r in result]
            # Insertamos encabezados como primera fila
            return [list(result.keys())] + rows

    # ------------------------- Prompts / Schema builders ----------------------

    def get_cypher_system_prompt(self) -> str:
        """Genera el prompt del sistema que incluye el esquema del grafo y contexto de AWS."""
        node_schema = self._get_nodes_schema()
        rel_schema = self._get_rel_schema()
        return f"""
            ## Tarea

            Genera consultas Cypher para Neo4j basándote en el esquema provisto.
            El grafo representa conocimiento extraído del documento:
            "AWS Documento técnico – Descripción general de Amazon Web Services".

            ## Instrucciones

            - Eres experto generando Cypher sobre Neo4j usando el esquema dado.
            - Usa únicamente los tipos de relaciones y propiedades disponibles.
            - Las relaciones suelen ser `RELATED_TO` y disponen de la propiedad `relation_type`
              (por ejemplo: 'DE', 'EN', 'CON', 'PARA', 'DESDE', etc.).
            - Evita duplicados usando DISTINCT cuando sea necesario.
            - Prefiere coincidencias insensibles a mayúsculas/minúsculas (toLower) sobre `n.name`.
            - Limita resultados si el conjunto es grande (por ejemplo, LIMIT 50).
            - Si no puedes generar una consulta válida con el esquema proporcionado, explica el motivo.

            ## Contexto del dominio (AWS)

            El usuario puede preguntar por:
            - Servicios (p. ej., "Amazon EC2", "Amazon S3", "AWS Lambda").
            - Categorías de servicios (Compute, Storage, Networking, Databases, Analytics, Security, etc.).
            - Regiones o ubicaciones (p. ej., disponibilidad "EN" ciertas regiones).
            - Características, integraciones y relaciones entre servicios (p. ej., servicios que funcionan "CON" otros).

            Considera que muchos vínculos están modelados como `(:ENTITY)-[r:RELATED_TO {{relation_type: <TIPO>}}]->(:ENTITY)`.

            ## Esquema

            {node_schema}

            {rel_schema}

            ## Ejemplos (guía)

            1) "¿Qué es Amazon EC2?"
               Sugerencia: buscar el nodo por nombre aproximado.
               MATCH (s:ENTITY)
               WHERE toLower(s.name) CONTAINS toLower('Amazon EC2')
               RETURN DISTINCT s.name AS servicio
               LIMIT 25;

            2) "¿Con qué servicios se integra Amazon S3?"
               Sugerencia: usar relaciones con tipo general como 'CON'.
               MATCH (a:ENTITY)-[r:RELATED_TO]->(b:ENTITY)
               WHERE toLower(a.name) CONTAINS toLower('Amazon S3')
                 AND r.relation_type IN ['CON']
               RETURN DISTINCT b.name AS integrado_con
               LIMIT 50;

            3) "Servicios relacionados con seguridad"
               Sugerencia: filtrar por nombre o palabra clave en nombre.
               MATCH (s:ENTITY)
               WHERE toLower(s.name) CONTAINS 'security' OR toLower(s.name) CONTAINS 'iam'
               RETURN DISTINCT s.name AS servicio
               LIMIT 50;

            Nota: Devuelve únicamente la consulta Cypher solicitada (sin explicaciones adicionales).
        """.strip()

    def _get_nodes_schema(self) -> str:
        """Obtiene el esquema de nodos del grafo usando APOC (llaves simples)."""
        node_properties_query = """
            CALL apoc.meta.data()
            YIELD label, other, elementType, type, property
            WHERE elementType = 'node' AND type <> 'RELATIONSHIP'
            WITH label AS nodeLabels, collect(DISTINCT property) AS properties
            RETURN {labels: nodeLabels, properties: properties} AS output
        """

        properties_descriptions = {
            "name": "Nombre legible de la entidad (puede contener mayúsculas/acentos)",
            "uri": "Identificador único normalizado en ASCII para la entidad",
            "source": "Fuente de la entidad (por ejemplo, 'pdf')",
        }

        node_props = self.query_database(node_properties_query)
        # node_props = [headers, row1, row2, ...] donde cada row es [output_dict]
        nodes = [row[0] for row in node_props[1:]]  # lista de dicts con keys: labels, properties

        node_descriptions = []
        for node in nodes:
            props = node.get("properties", []) if isinstance(node, dict) else []
            labels = node.get("labels", "") if isinstance(node, dict) else ""
            listable_properties = sorted([p for p in props if p in properties_descriptions])
            node_description = f" - {labels}, with properties: {', '.join(listable_properties) if listable_properties else '(none matched)'}"
            node_descriptions.append(node_description)

        prop_descriptions = [f" - {prop}: {properties_descriptions[prop]}" for prop in sorted(properties_descriptions)]

        property_description_instructions = [
            "### Nodos",
            "",
            "A continuación se listan los nodos del grafo junto con sus propiedades.",
            "Las descripciones de propiedades se listan al final.",
            "",
            *node_descriptions,
            "",
            "Descripciones de propiedades:",
            *prop_descriptions,
        ]

        return "\n".join(property_description_instructions)

    def _get_rel_schema(self) -> str:
        """Obtiene el esquema de relaciones del grafo usando APOC (llaves simples y elementType correcto)."""
        rel_query = """
            CALL apoc.meta.data()
            YIELD label, other, elementType, type, property
            WHERE elementType = 'relationship'
            RETURN {source: label, relationship: property, target: other} AS output
        """

        rels = self.query_database(rel_query)
        rels = [r[0] for r in rels[1:]]  # lista de dicts con keys: source, relationship, target

        rel_descriptions = []
        for rel in rels:
            if not isinstance(rel, dict):
                continue
            src = rel.get("source", "")
            rel_name = rel.get("relationship", "")
            tgt_raw = rel.get("target", [])
            targets = tgt_raw if isinstance(tgt_raw, (list, tuple)) else [tgt_raw]
            targets_str = ", ".join([f"`{t}`" for t in targets])
            rel_description = f" - `{rel_name}`, that relates `{src}` with {targets_str}"
            rel_descriptions.append(rel_description)

        rel_props_descriptions = {
            "relation_type": "Tipo de relación entre entidades (p. ej., 'DE', 'EN', 'CON')",
            "source": "Fuente de la relación (por ejemplo, 'pdf')"
        }

        rel_props_descriptions_list = [
            f" - {prop}: {rel_props_descriptions[prop]}" for prop in sorted(rel_props_descriptions)
        ]

        rels_description_instructions = [
            "### Relaciones",
            "",
            "A continuación se listan las relaciones presentes en el grafo",
            "",
        ]
        if rel_descriptions:
            rels_description_instructions.extend(rel_descriptions)
        else:
            rels_description_instructions.append(" - (no relationships found)")
        
        rels_description_instructions.extend([
            "",
            "Property descriptions:",
        ])
        rels_description_instructions.extend(rel_props_descriptions_list)

        return "\n".join(rels_description_instructions)

    # ------------------------------- OpenAI calls -----------------------------

    def get_candidate_cypher_query(self, question: str) -> str:
        """Usa OpenAI para generar una query Cypher basada en la pregunta y el esquema."""
        system_prompt = self.get_cypher_system_prompt()
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": question},
        ]

        resp = self.openai_client.chat.completions.create(
            model=self.openai_model,
            messages=messages,
            temperature=0,
            max_tokens=1000,
        )
                
        return resp.choices[0].message.content

    def generate_response(self, question: str, results_table: str) -> str:
        print(f"PASO 5: Generando respuesta con GPT")
        """Usa OpenAI para generar una respuesta natural basada en los resultados (orientada a AWS)."""
        generation_system_instruction = """
            Eres un asistente útil que responde en español basándose únicamente en la tabla de resultados
            proveniente de una consulta al grafo (sin mencionarlo). Los resultados pueden representar
            entidades, relaciones, conteos o conexiones entre entidades extraídas del documento de AWS
            (Descripción general de Amazon Web Services).

            Instrucciones:
            - Responde clara y concisamente en español, enfocándote en servicios, categorías, regiones,
              características e integraciones cuando aplique.
            - No inventes datos: usa solo la información presente en la tabla de resultados.
            - Si la tabla está vacía o es insuficiente, explícalo de forma educada y sugiere consultas
              alternativas o términos más específicos.
            - No incluyas enlaces ni URLs.
        """.strip()

        generation_prompt = f"""Estos son los resultados de una consulta relacionada con la pregunta del usuario:

            {results_table}

            Pregunta del usuario (responde usando únicamente los resultados):

            {question}
        """

        resp = self.openai_client.chat.completions.create(
            model=self.openai_model,
            temperature=0.0,
            max_tokens=1000,
            messages=[
                {"role": "system", "content": generation_system_instruction},
                {"role": "user", "content": generation_prompt},
            ],
        )
        return resp.choices[0].message.content

    # -------------------------------- Cleanup --------------------------------

    def close(self):
        """Cierra la conexión a Neo4j."""
        if self.driver is not None:
            self.driver.close()

    def __del__(self):
        # Intento de cierre seguro al recolectarse el objeto
        try:
            self.close()
        except Exception:
            pass


# ------------------------------- Ejemplo de uso -------------------------------
# from this_module import PDFKnowledgeGraph, format_results_as_markdown_table
#
# kg = PDFKnowledgeGraph()
# pregunta = "¿Cuántas organizaciones hay en el documento?"
# cypher_query = kg.get_candidate_cypher_query(pregunta)
# results = kg.query_database(cypher_query)
# tabla = format_results_as_markdown_table(results)
# respuesta = kg.generate_response(pregunta, tabla)
# print("Query Cypher:\n", cypher_query)
# print("Resultados:\n", tabla)
# print("Respuesta:\n", respuesta)
# kg.close()
