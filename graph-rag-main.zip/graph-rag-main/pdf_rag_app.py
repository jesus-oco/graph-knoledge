"""
Aplicación Streamlit para interactuar con el grafo de conocimiento del PDF usando RAG.
Orientada al documento: "AWS Documento técnico – Descripción general de Amazon Web Services".
Permite preguntar sobre servicios, categorías, regiones, características e integraciones.
"""

import os

import streamlit as st
from dotenv import load_dotenv
from pdf_kg import PDFKnowledgeGraph, format_results_as_markdown_table

load_dotenv()

# Inicializar el Knowledge Graph
if 'kg' not in st.session_state:
    st.session_state.kg = PDFKnowledgeGraph()

kg = st.session_state.kg

st.set_page_config(layout="wide", page_title="Graph-RAG del documento de AWS")

st.title("📄 Graph-RAG del documento de AWS")
st.markdown(
    "Haz preguntas sobre los datos extraídos del PDF de AWS (Descripción general de Amazon Web Services) usando Graph-RAG"
)

# Sidebar con información
with st.sidebar:
    st.header("ℹ️ Información")
    st.markdown("""
    Este sistema usa:
    - **GPT (OpenAI)**: Para generar queries Cypher y respuestas naturales
    - **Neo4j**: Para almacenar y consultar el grafo de conocimiento
    
    Dominio: Documento de AWS (servicios, categorías, regiones, integraciones).
    """)
    
    st.markdown("---")
    st.markdown("### 📊 Estadísticas del Grafo")
    
    # Mostrar estadísticas básicas
    try:
        stats_query = """
        MATCH (n:ENTITY) WHERE n.source = 'pdf'
        RETURN count(n) as total_entities
        """
        stats = kg.query_database(stats_query)
        if stats and len(stats) > 1:
            total = stats[1][0]
            st.metric("Entidades", total)
        
        rel_stats_query = """
        MATCH ()-[r:RELATED_TO]->() WHERE r.source = 'pdf'
        RETURN count(r) as total_relations
        """
        rel_stats = kg.query_database(rel_stats_query)
        if rel_stats and len(rel_stats) > 1:
            total_rel = rel_stats[1][0]
            st.metric("Relaciones", total_rel)
    except Exception as e:
        st.warning(f"No se pudieron cargar estadísticas: {e}")

# Input de pregunta
prompt = st.text_input(
    "💬 Haz una pregunta sobre el documento de AWS:",
    placeholder="Ej: ¿Con qué servicios se integra Amazon S3? | Lista servicios relacionados con seguridad | ¿Qué servicios de almacenamiento menciona el documento?",
    key="question_input"
)

if prompt:
    with st.spinner("🔍 Generando query Cypher y consultando el grafo..."):
        try:
            # 1. Generar query Cypher usando GPT
            cypher_query = kg.get_candidate_cypher_query(prompt)
            
            # 2. Ejecutar query en Neo4j
            results_query = kg.query_database(cypher_query)
            
            # 3. Formatear resultados
            formatted_results = format_results_as_markdown_table(results_query)
            
            # 4. Generar respuesta usando GPT
            response = kg.generate_response(prompt, formatted_results)
            
            # Mostrar respuesta
            st.markdown("### 📝 Respuesta")
            st.markdown(response)
            
            st.divider()
            
            # Mostrar detalles técnicos
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("### 🔍 Query Cypher Generada")
                st.code(cypher_query, language="cypher")
            
            with col2:
                st.markdown("### 📊 Resultados de la Query")
                if formatted_results:
                    st.markdown(formatted_results)
                else:
                    st.info("No se encontraron resultados para esta query.")
            
        except Exception as e:
            st.error(f"❌ Error al procesar la pregunta: {e}")
            st.exception(e)

# Ejemplos de preguntas
with st.expander("💡 Ejemplos de preguntas que puedes hacer"):
    st.markdown("""
    - **Servicios (AWS)**: 
      - "¿Con qué servicios se integra Amazon S3?"
      - "¿Con qué servicios se integra AWS Lambda?"
      - "Lista los servicios relacionados con seguridad (security/IAM)"

    - **Categorías y almacenamiento**:
      - "¿Qué servicios de almacenamiento menciona el documento?"
      - "Lista servicios de bases de datos"

    - **Regiones e integración**:
      - "¿Qué servicios aparecen EN la región us-east-1?"
      - "Muestra relaciones de tipo CON/EN para Amazon EC2"
    """)

